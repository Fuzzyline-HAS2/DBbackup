-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: has2
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device` (
  `device_name` varchar(45) NOT NULL,
  `device_type` varchar(45) NOT NULL,
  `mac` varchar(45) DEFAULT 'mac not found',
  `theme` varchar(45) NOT NULL DEFAULT 'Cyberpunk',
  `shift_machine` int NOT NULL DEFAULT '1',
  `restart` int NOT NULL DEFAULT '0',
  `watchdog` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`device_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
INSERT INTO `device` VALUES ('BD','tagmachine','mac not found','cyberpunk',4,0,0),('BE','escapemachine','mac not found','cyberpunk',2,0,0),('BG','generator','mac not found','cyberpunk',4,0,0),('BI1','itembox','mac not found','cyberpunk',4,0,0),('BI2','itembox','mac not found','cyberpunk',4,0,0),('BR1','revivalmachine','mac not found','cyberpunk',2,0,0),('BR2','revivalmachine','mac not found','cyberpunk',2,0,0),('BT','temple','78:21:84:92:E9:D0','cyberpunk',2,0,0),('BV1','duct','mac not found','cyberpunk',4,0,0),('BV2','duct','mac not found','cyberpunk',4,0,0),('cyberpunkOS','mp3','58:BF:25:04:8F:70','cyberpunk',0,1,0),('FD1','tagmachine','mac not found','cyberpunk',4,0,0),('FD2','tagmachine','mac not found','3',78,0,0),('FE','escapemachine','mac not found','cyberpunk',2,0,0),('FG','generator','mac not found','cyberpunk',4,0,0),('FI1','itembox','mac not found','cyberpunk',4,0,0),('FI2','itembox','mac not found','cyberpunk',4,0,0),('FR1','revivalmachine','mac not found','cyberpunk',2,0,0),('FR2','revivalmachine','mac not found','cyberpunk',4,0,0),('FV','duct','mac not found','cyberpunk',4,0,0),('G1P1','iotglove','58:BF:25:04:90:8C','cyberpunk',2,1,0),('G1P2','iotglove','78:21:84:92:EC:A4','cyberpunk',2,0,0),('G1P3','iotglove','78:21:84:92:E8:70','cyberpunk',2,0,0),('G1P4','iotglove','78:21:84:92:EA:00','cyberpunk',2,1,0),('G1P5','iotglove','mac not found','cyberpunk',2,0,0),('G1P6','iotglove','mac not found','cyberpunk',2,0,0),('G1P7','iotglove','mac not found','cyberpunk',2,0,0),('G1P8','iotglove','mac not found','cyberpunk',2,0,0),('G2P1','iotglove','','exerciseroom',2,0,0),('G2P2','iotglove','mac not found','exerciseroom',2,0,0),('G2P3','iotglove','mac not found','exerciseroom',2,0,0),('G2P4','iotglove','mac not found','exerciseroom',2,0,0),('G2P5','iotglove','mac not found','exerciseroom',2,0,0),('G2P6','iotglove','mac not found','exerciseroom',2,0,0),('G2P7','iotglove','mac not found','exerciseroom',2,0,0),('G2P8','iotglove','mac not found','exerciseroom',2,0,0),('G3P1','iotglove','mac not found','waiting',1,0,0),('G3P2','iotglove','mac not found','waiting',1,0,0),('G3P3','iotglove','mac not found','waiting',1,0,0),('G3P4','iotglove','mac not found','waiting',1,0,0),('G3P5','iotglove','mac not found','waiting',1,0,0),('G3P6','iotglove','mac not found','waiting',1,0,0),('G3P7','iotglove','mac not found','waiting',1,0,0),('G3P8','iotglove','mac not found','waiting',1,0,0),('G4P1','iotglove','mac not found','waiting',1,0,0),('G4P2','iotglove','mac not found','waiting',1,0,0),('G4P3','iotglove','mac not found','waiting',1,0,0),('G4P4','iotglove','mac not found','waiting',1,0,0),('G4P5','iotglove','mac not found','waiting',1,0,0),('G4P6','iotglove','mac not found','waiting',1,0,0),('G4P7','iotglove','mac not found','waiting',1,0,0),('G4P8','iotglove','mac not found','waiting',1,0,0),('GD','tagmachine','mac not found','cyberpunk',4,0,0),('GG','generator','mac not found','cyberpunk',4,0,0),('GI1','itembox','mac not found','cyberpunk',4,0,0),('GI2','itembox','mac not found','cyberpunk',4,0,0),('GR1','revivalmachine','mac not found','cyberpunk',4,0,0),('GR2','revivalmachine','mac not found','cyberpunk',2,0,0),('GV1','duct','mac not found','cyberpunk',4,0,0),('GV2','duct','mac not found','cyberpunk',4,0,0),('HD1','tagmachine','mac not found','cyberpunk',4,0,0),('HD2','tagmachine','mac not found','cyberpunk',4,0,0),('HG','generator','mac not found','cyberpunk',4,0,0),('HI1','itembox','mac not found','cyberpunk',4,0,0),('HI2','itembox','mac not found','cyberpunk',4,0,0),('HR1','revivalmachine','mac not found','cyberpunk',2,0,0),('HR2','revivalmachine','mac not found','cyberpunk',4,0,0),('HV1','duct','mac not found','cyberpunk',4,0,0),('HV2','duct','mac not found','cyberpunk',4,0,0),('OD','tagmachine','mac not found','cyberpunk',4,0,0),('OE','escapemachine','mac not found','cyberpunk',2,0,0),('OG','generator','mac not found','cyberpunk',4,0,0),('OI1','itembox','mac not found','cyberpunk',4,0,0),('OI2','itembox','mac not found','cyberpunk',4,0,0),('OR1','revivalmachine','78:21:84:92:ED:E0','cyberpunk',4,0,0),('OR2','revivalmachine','58:BF:25:04:8A:E4','cyberpunk',2,0,0),('OV','duct','mac not found','3',78,0,0);
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-29 14:30:04
