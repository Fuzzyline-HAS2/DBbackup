-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: has2
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device` (
  `device_name` varchar(45) NOT NULL,
  `device_type` varchar(45) NOT NULL,
  `mac` varchar(45) DEFAULT 'mac not found',
  `theme` varchar(45) NOT NULL DEFAULT 'Cyberpunk',
  `shift_machine` int NOT NULL DEFAULT '1',
  `restart` int NOT NULL DEFAULT '0',
  `watchdog` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`device_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
INSERT INTO `device` VALUES ('AD1','tagmachine','mac not found','cyberpunk',1,0,0),('AG1','generator','mac not found','cyberpunk',1,0,0),('AI1','itembox','mac not found','cyberpunk',1,0,0),('AI2','itembox','mac not found','cyberpunk',1,0,0),('AL1','lifemachine','mac not found','cyberpunk',1,0,0),('AL2','lifemachine','mac not found','cyberpunk',1,0,0),('AV1','duct','mac not found','cyberpunk',1,0,0),('BD1','tagmachine','mac not found','cyberpunk',1,0,0),('BG1','generator','mac not found','cyberpunk',1,0,0),('BI1','itembox','mac not found','cyberpunk',1,0,0),('BI2','itembox','mac not found','cyberpunk',1,0,0),('BL1','lifemachine','mac not found','cyberpunk',1,0,0),('BL2','lifemachine','mac not found','cyberpunk',1,0,0),('BT1','temple','mac not found','cyberpunk',1,0,0),('BV1','duct','mac not found','cyberpunk',1,0,0),('G1P1','iotglove','mac not found','waiting',1,0,0),('G1P2','iotglove','mac not found','waiting',1,0,0),('G1P3','iotglove','mac not found','waiting',1,0,0),('G1P4','iotglove','mac not found','waiting',1,0,0),('G1P5','iotglove','mac not found','waiting',1,0,0),('G1P6','iotglove','mac not found','waiting',1,0,0),('G1P7','iotglove','mac not found','waiting',1,0,0),('G1P8','iotglove','mac not found','waiting',1,0,0),('G2P1','iotglove','mac not found','waiting',1,0,0),('G2P2','iotglove','mac not found','waiting',1,0,0),('G2P3','iotglove','mac not found','waiting',1,0,0),('G2P4','iotglove','mac not found','waiting',1,0,0),('G2P5','iotglove','mac not found','waiting',1,0,0),('G2P6','iotglove','mac not found','waiting',1,0,0),('G2P7','iotglove','mac not found','waiting',1,0,0),('G2P8','iotglove','mac not found','waiting',1,0,0),('GD1','tagmachine','mac not found','cyberpunk',1,0,0),('GE1','escapemachine','mac not found','cyberpunk',1,0,0),('GG1','generator','mac not found','cyberpunk',1,0,0),('GI1','itembox','mac not found','cyberpunk',1,0,0),('GI2','itembox','mac not found','cyberpunk',1,0,0),('GL1','lifemachine','mac not found','cyberpunk',1,0,0),('GL2','lifemachine','mac not found','cyberpunk',1,0,0),('GV1','duct','mac not found','cyberpunk',1,0,0),('OD1','tagmachine','mac not found','cyberpunk',1,0,0),('OE1','escapemachine','mac not found','cyberpunk',1,0,0),('OG1','generator','mac not found','cyberpunk',1,0,0),('OI1','itembox','mac not found','cyberpunk',1,0,0),('OI2','itembox','mac not found','cyberpunk',1,0,0),('OL1','lifemachine','mac not found','cyberpunk',1,0,0),('OL2','lifemachine','mac not found','cyberpunk',1,0,0),('OV1','duct','mac not found','cyberpunk',1,0,0),('RD1','tagmachine','mac not found','cyberpunk',1,0,0),('RE1','escapemachine','mac not found','cyberpunk',1,0,0),('RG1','generator','mac not found','cyberpunk',1,0,0),('RI1','itembox','mac not found','cyberpunk',1,0,0),('RI2','itembox','mac not found','cyberpunk',1,0,0),('RL1','lifemachine','mac not found','cyberpunk',1,0,0),('RL2','lifemachine','mac not found','cyberpunk',1,0,0),('RV1','duct','mac not found','cyberpunk',1,0,0);
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-26 15:22:42
