-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: has2
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `iotglove`
--

DROP TABLE IF EXISTS `iotglove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iotglove` (
  `player_name` varchar(45) DEFAULT NULL,
  `device_type` varchar(45) NOT NULL,
  `game_state` varchar(45) NOT NULL DEFAULT 'stop',
  `device_state` varchar(45) NOT NULL DEFAULT 'stop',
  `manage_state` varchar(45) DEFAULT NULL,
  `role` varchar(45) NOT NULL DEFAULT 'neutral',
  `life_chip` int NOT NULL DEFAULT '1',
  `max_life_chip` int NOT NULL DEFAULT '3',
  `taken_chip` int NOT NULL DEFAULT '0',
  `max_taken_chip` int NOT NULL DEFAULT '3',
  `battery_pack` int NOT NULL DEFAULT '0',
  `max_battery_pack` int NOT NULL DEFAULT '3',
  `exp` int NOT NULL DEFAULT '0',
  `max_exp` int NOT NULL DEFAULT '100',
  `lv` int NOT NULL DEFAULT '1',
  `skill_point` int NOT NULL DEFAULT '0',
  `mode` varchar(45) NOT NULL DEFAULT 'day',
  `location` varchar(45) NOT NULL DEFAULT 'not found',
  `tagger_name` varchar(45) DEFAULT NULL,
  `vibe` int NOT NULL DEFAULT '0',
  `message_sender` varchar(45) DEFAULT NULL,
  `message_code` int DEFAULT NULL,
  `revival_time` int NOT NULL DEFAULT '60',
  PRIMARY KEY (`device_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iotglove`
--

LOCK TABLES `iotglove` WRITE;
/*!40000 ALTER TABLE `iotglove` DISABLE KEYS */;
INSERT INTO `iotglove` VALUES (NULL,'iotglove','setting','setting',NULL,'neutral',1,3,0,1,0,4,0,100,1,0,'day','not found',NULL,0,NULL,NULL,60);
/*!40000 ALTER TABLE `iotglove` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-06 23:47:41
