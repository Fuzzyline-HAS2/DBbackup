-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: has2
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `skill`
--

DROP TABLE IF EXISTS `skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `skill` (
  `SkillCode` char(20) NOT NULL,
  `SkillName` char(20) NOT NULL,
  `Role` char(20) NOT NULL,
  `Probability` char(20) NOT NULL,
  `UsedDevice` char(20) NOT NULL,
  `AffectedDevice` char(20) NOT NULL,
  `Grade` char(20) NOT NULL,
  `SkillClass` char(20) NOT NULL,
  `Active` char(20) NOT NULL,
  `Step` int NOT NULL,
  `MaxStep` int NOT NULL,
  `AppearBoard` int NOT NULL,
  PRIMARY KEY (`SkillCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill`
--

LOCK TABLES `skill` WRITE;
/*!40000 ALTER TABLE `skill` DISABLE KEYS */;
INSERT INTO `skill` VALUES ('AE2','Scapegoat','Player','100','temple','temple','Epic','Life','Passive',0,1,0),('CL1','Tracker\'s Instinct','Player','100','common','common','Legend','Common','Passive',0,1,0),('DR1','Camouflage Shift','Player','100','duct','duct','Rare','Move','Passive',0,1,0),('EL1','Soulmate','Player','100','escapemachine','escapemachine','Legend','Common','Passive',0,1,0),('GN1','Engineer','Player','100','generator','generator','Normal','Repair','Passive',0,3,0),('IR1','LockSmith','Player','100','itembox','itembox','Rare','Repair','Passive',0,1,0),('KAE2','Control','Tagger','100','temple','generator','Epic','Life','Passive',0,3,0),('KCE1','Massacre','Tagger','100','common','iotglove','Epic','Common','Passive',0,3,0),('KDL1','Duc-trap','Tagger','100','duct','duct','Legend','Move','Passive',0,1,0),('KEE2','Endgame2','Tagger','100','escapemachine','duct','Epic','Common','Passive',0,2,0),('KGL1','Leakage','Tagger','100','generator','generator,itembox','Legend','Repair','Active',0,1,0),('KIN2','Ground','Tagger','100','itembox','tagmachine,duct','Normal','Repair','Passive',0,2,0),('KLE2','Avarice','Tagger','100','lifemachine','generator','Epic','Life','Passive',0,1,0),('KTN1','Complexity','Tagger','100','tagmachine','tagmachine','Normal','Move','Passive',0,3,0),('LR1','Medic','Player','100','lifemachine','iotglove','Rare','Life','Active',0,3,0),('TN1','Ghost','Player','100','tagmachine','tagmachine','Normal','Move','Passive',0,3,0);
/*!40000 ALTER TABLE `skill` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-06 23:47:41
