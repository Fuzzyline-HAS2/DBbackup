-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: has2
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cyberpunk_revivalmachine`
--

DROP TABLE IF EXISTS `cyberpunk_revivalmachine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cyberpunk_revivalmachine` (
  `device_name` varchar(45) NOT NULL,
  `device_type` varchar(45) NOT NULL,
  `game_state` varchar(45) NOT NULL,
  `device_state` varchar(45) NOT NULL,
  `manage_state` varchar(45) DEFAULT NULL,
  `life_chip` int NOT NULL,
  `activate_num` int NOT NULL,
  `light_mode` varchar(45) NOT NULL,
  `game_mode` varchar(45) NOT NULL,
  PRIMARY KEY (`device_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyberpunk_revivalmachine`
--

LOCK TABLES `cyberpunk_revivalmachine` WRITE;
/*!40000 ALTER TABLE `cyberpunk_revivalmachine` DISABLE KEYS */;
INSERT INTO `cyberpunk_revivalmachine` VALUES ('BR1','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('BR2','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('FR1','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('FR2','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('GR1','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('GR2','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('HR1','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('HR2','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('OR1','revivalmachine','setting','setting',NULL,1,1,'day','normal'),('OR2','revivalmachine','setting','setting',NULL,1,1,'day','normal');
/*!40000 ALTER TABLE `cyberpunk_revivalmachine` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-06 23:47:41
