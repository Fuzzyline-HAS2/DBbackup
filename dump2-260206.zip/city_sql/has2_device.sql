-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: has2
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device` (
  `device_name` varchar(45) NOT NULL,
  `device_type` varchar(45) NOT NULL,
  `mac` varchar(45) DEFAULT 'mac not found',
  `theme` varchar(45) NOT NULL DEFAULT 'Cyberpunk',
  `shift_machine` int NOT NULL DEFAULT '1',
  `restart` int NOT NULL DEFAULT '0',
  `watchdog` int NOT NULL DEFAULT '0',
  `selected_language` char(2) DEFAULT NULL,
  PRIMARY KEY (`device_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
INSERT INTO `device` VALUES ('BD','tagmachine','A0:DD:6C:75:05:28','cyberpunk',2,0,0,'KO'),('BE','escapemachine','4C:EB:D6:43:45:08','cyberpunk',2,0,0,'KO'),('BG','generator','78:21:84:92:E9:9C','cyberpunk',2,0,0,'KO'),('BI1','itembox','78:21:84:92:EC:FC','cyberpunk',2,0,0,'KO'),('BI2','itembox','4C:EB:D6:43:4B:6C','cyberpunk',2,0,0,'KO'),('BR1','revivalmachine','80:B5:4E:C6:4F:FC','cyberpunk',2,0,0,'KO'),('BR2','revivalmachine','4C:EB:D6:43:44:98','cyberpunk',2,0,0,'KO'),('BT','temple','4C:EB:D6:43:46:3C','cyberpunk',2,0,0,'KO'),('BV1','duct','4C:EB:D6:43:43:74','cyberpunk',2,0,0,'KO'),('BV2','duct','4C:EB:D6:43:43:DC','cyberpunk',2,0,0,'KO'),('cyberpunkOS','mp3','4C:EB:D6:43:44:24','cyberpunk',2,1,0,'KO'),('FD1','tagmachine','78:21:84:92:EB:F0','cyberpunk',2,0,0,'KO'),('FE','escapemachine','78:21:84:92:EC:94','cyberpunk',2,0,0,'KO'),('FG','generator','78:21:84:92:E7:E8','cyberpunk',2,0,0,'KO'),('FI1','itembox','4C:EB:D6:43:46:F0','cyberpunk',2,0,0,'KO'),('FI2','itembox','4C:EB:D6:43:47:E4','cyberpunk',2,0,0,'KO'),('FR1','revivalmachine','4C:EB:D6:43:47:F0','cyberpunk',2,0,0,'KO'),('FR2','revivalmachine','4C:EB:D6:43:4A:8C','cyberpunk',2,0,0,'KO'),('FV','duct','4C:EB:D6:43:44:B8','cyberpunk',2,0,0,'KO'),('G1P1','iotglove','A0:DD:6C:75:07:44','waiting',2,1,0,'KO'),('G1P2','iotglove','4C:EB:D6:43:4B:5C','waiting',2,0,0,'KO'),('G1P3','iotglove','08:F9:E0:F4:87:8C','waiting',2,0,0,'KO'),('G1P4','iotglove','78:21:84:92:E8:00','waiting',2,1,0,'KO'),('G1P5','iotglove','08:F9:E0:F3:D6:F8','waiting',2,0,0,'KO'),('G1P6','iotglove','A0:DD:6C:75:08:88','waiting',2,0,0,'KO'),('G1P7','iotglove','A0:DD:6C:75:09:90','waiting',2,0,0,'KO'),('G1P8','iotglove','A0:DD:6C:75:08:00','waiting',2,0,0,'KO'),('G2P1','iotglove','4C:EB:D6:43:44:60','cyberpunk',2,0,0,'KO'),('G2P2','iotglove','2C:BC:BB:A8:4D:1C','cyberpunk',2,0,0,'KO'),('G2P3','iotglove','4C:EB:D6:43:45:A0','cyberpunk',2,0,0,'KO'),('G2P4','iotglove','4C:EB:D6:43:48:BC','cyberpunk',2,0,0,'KO'),('G2P5','iotglove','08:F9:E0:F4:02:80','cyberpunk',2,0,0,'KO'),('G2P6','iotglove','4C:EB:D6:43:43:90','cyberpunk',2,0,0,'KO'),('G2P7','iotglove','58:BF:25:04:8E:A8','cyberpunk',2,0,0,'KO'),('G2P8','iotglove','08:F9:E0:F3:7F:C4','cyberpunk',2,0,0,'KO'),('G3P1','iotglove','mac not found','waiting',3,0,0,'KO'),('G3P2','iotglove','mac not found','waiting',3,0,0,'KO'),('G3P3','iotglove','mac not found','waiting',3,0,0,'KO'),('G3P4','iotglove','mac not found','waiting',3,0,0,'KO'),('G3P5','iotglove','mac not found','waiting',3,0,0,'KO'),('G3P6','iotglove','mac not found','waiting',3,0,0,'KO'),('G3P7','iotglove','mac not found','waiting',3,0,0,'KO'),('G3P8','iotglove','mac not found','waiting',3,0,0,'KO'),('G4P1','iotglove','mac not found','waiting',2,0,0,'KO'),('G4P2','iotglove','mac not found','waiting',2,0,0,'KO'),('G4P3','iotglove','mac not found','waiting',2,0,0,'KO'),('G4P4','iotglove','mac not found','waiting',2,0,0,'KO'),('G4P5','iotglove','mac not found','waiting',2,0,0,'KO'),('G4P6','iotglove','mac not found','waiting',2,0,0,'KO'),('G4P7','iotglove','mac not found','waiting',2,0,0,'KO'),('G4P8','iotglove','mac not found','waiting',2,0,0,'KO'),('GD','tagmachine','4C:EB:D6:43:48:D0','cyberpunk',2,0,0,'KO'),('GG','generator','78:21:84:92:E7:7C','cyberpunk',2,0,0,'KO'),('GI1','itembox','4C:EB:D6:43:47:38','cyberpunk',2,0,0,'KO'),('GI2','itembox','A0:DD:6C:75:06:14','cyberpunk',2,0,0,'KO'),('GR1','revivalmachine','78:21:84:92:E7:F4','cyberpunk',2,0,0,'KO'),('GR2','revivalmachine','4C:EB:D6:43:46:18','cyberpunk',2,0,0,'KO'),('GV1','duct','A0:DD:6C:75:07:FC','cyberpunk',2,0,0,'KO'),('GV2','duct','58:BF:25:04:97:50','cyberpunk',2,0,0,'KO'),('HD1','tagmachine','78:21:84:92:E6:B8','cyberpunk',2,0,0,'KO'),('HD2','tagmachine','78:21:84:92:E8:58','cyberpunk',2,0,0,'KO'),('HG','generator','4C:EB:D6:43:4A:F4','cyberpunk',2,0,0,'KO'),('HI1','itembox','4C:EB:D6:43:43:70','cyberpunk',2,0,0,'KO'),('HI2','itembox','4C:EB:D6:43:48:C0','cyberpunk',2,0,0,'KO'),('HR1','revivalmachine','4C:EB:D6:43:4B:04','cyberpunk',2,0,0,'KO'),('HR2','revivalmachine','78:21:84:92:EC:38','cyberpunk',2,0,0,'KO'),('HV1','duct','4C:EB:D6:43:46:30','cyberpunk',2,0,0,'KO'),('OD','tagmachine','4C:EB:D6:43:44:28','cyberpunk',2,0,0,'KO'),('OE','escapemachine','4C:EB:D6:43:43:34','cyberpunk',2,0,0,'KO'),('OG','generator','4C:EB:D6:43:4B:60','cyberpunk',2,0,0,'KO'),('OI1','itembox','4C:EB:D6:43:45:80','cyberpunk',2,0,0,'KO'),('OI2','itembox','4C:EB:D6:43:48:88','cyberpunk',2,0,0,'KO'),('OR1','revivalmachine','4C:EB:D6:43:4A:BC','cyberpunk',2,0,0,'KO'),('OR2','revivalmachine','4C:EB:D6:43:4B:2C','cyberpunk',2,0,0,'KO');
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-06 23:47:42
