-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: has2
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cyberpunk_itembox`
--

DROP TABLE IF EXISTS `cyberpunk_itembox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cyberpunk_itembox` (
  `device_name` varchar(45) NOT NULL,
  `device_type` varchar(45) NOT NULL,
  `game_state` varchar(45) NOT NULL,
  `device_state` varchar(45) NOT NULL,
  `manage_state` varchar(45) DEFAULT NULL,
  `battery_pack` int NOT NULL,
  `exp_pack` int NOT NULL,
  `light_mode` varchar(45) NOT NULL,
  `game_mode` varchar(45) NOT NULL,
  PRIMARY KEY (`device_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cyberpunk_itembox`
--

LOCK TABLES `cyberpunk_itembox` WRITE;
/*!40000 ALTER TABLE `cyberpunk_itembox` DISABLE KEYS */;
INSERT INTO `cyberpunk_itembox` VALUES ('BI1','itembox','setting','open',NULL,1,50,'day','normal'),('BI2','itembox','setting','open',NULL,1,50,'day','normal'),('FI1','itembox','setting','open',NULL,1,50,'day','normal'),('FI2','itembox','setting','open',NULL,1,50,'day','normal'),('GI1','itembox','setting','open',NULL,1,50,'day','normal'),('GI2','itembox','setting','open',NULL,1,50,'day','normal'),('HI1','itembox','setting','open',NULL,1,50,'day','normal'),('HI2','itembox','setting','open',NULL,1,50,'day','normal'),('OI1','itembox','setting','open',NULL,1,50,'day','normal'),('OI2','itembox','setting','open',NULL,1,50,'day','normal');
/*!40000 ALTER TABLE `cyberpunk_itembox` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-06 23:47:42
