-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: has2
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `iotglove_g2`
--

DROP TABLE IF EXISTS `iotglove_g2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iotglove_g2` (
  `device_name` varchar(45) NOT NULL,
  `player_name` varchar(45) DEFAULT NULL,
  `device_type` varchar(45) NOT NULL,
  `game_state` varchar(45) NOT NULL,
  `device_state` varchar(45) NOT NULL,
  `manage_state` varchar(45) DEFAULT NULL,
  `role` varchar(45) NOT NULL,
  `life_chip` int NOT NULL,
  `max_life_chip` int NOT NULL,
  `taken_chip` int NOT NULL,
  `max_taken_chip` int NOT NULL,
  `battery_pack` int NOT NULL,
  `max_battery_pack` int NOT NULL,
  `exp` int NOT NULL,
  `max_exp` int NOT NULL,
  `lv` int NOT NULL,
  `skill_point` int NOT NULL,
  `mode` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  `tagger_name` varchar(45) DEFAULT NULL,
  `vibe` int NOT NULL DEFAULT '0',
  `message_sender` varchar(45) DEFAULT NULL,
  `message_code` int DEFAULT NULL,
  `revival_time` int NOT NULL DEFAULT '60',
  PRIMARY KEY (`device_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iotglove_g2`
--

LOCK TABLES `iotglove_g2` WRITE;
/*!40000 ALTER TABLE `iotglove_g2` DISABLE KEYS */;
INSERT INTO `iotglove_g2` VALUES ('G2P1','1','iotglove','activate','activate',NULL,'player',2,3,0,1,0,4,90,100,1,0,'day','not found','G2P2',0,NULL,NULL,60),('G2P2',NULL,'iotglove','activate','activate',NULL,'tagger',1,3,0,1,0,4,0,100,1,0,'day','not found','G2P2',0,NULL,NULL,60),('G2P3','2','iotglove','activate','activate',NULL,'player',1,3,0,1,0,4,0,100,1,0,'day','not found','G2P2',0,NULL,NULL,60),('G2P4','3','iotglove','activate','activate',NULL,'player',1,3,0,1,0,4,0,100,1,0,'day','not found','G2P2',0,NULL,NULL,60),('G2P5','4','iotglove','activate','activate',NULL,'player',1,3,0,1,0,4,0,100,1,0,'day','not found','G2P2',0,NULL,NULL,60),('G2P6','5','iotglove','activate','activate',NULL,'player',1,3,0,1,0,4,0,100,1,0,'day','not found','G2P2',0,NULL,NULL,60),('G2P7','6','iotglove','activate','activate',NULL,'player',1,3,0,1,0,4,0,100,1,0,'day','not found','G2P2',0,NULL,NULL,60),('G2P8','7','iotglove','activate','activate',NULL,'player',1,3,0,1,0,4,0,100,1,0,'day','not found','G2P2',0,NULL,NULL,60);
/*!40000 ALTER TABLE `iotglove_g2` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-06 23:47:42
